#!/usr/bin/env python3


import logging
import asyncio
import pickle
from aiocoap import *

logging.basicConfig(level=logging.INFO)

async def client_function():
    protocol = await Context.create_client_context()

    request = Message(code=GET, uri='coap://localhost/lightdata')

    try:
        response = await protocol.request(request).response
    except Exception as e:
        print('Failed to fetch resource:')
        print(e)
    else:
        payload = response.payload
        payload = payload.decode('utf-8')
        print('Result: %s\n%r'%(response.code, payload))
        print(payload)
#asyncio.get_event_loop().run_until_complete(client_function())
